// REQUIRE STATEMENTS FOR ADDITIONAL PACKAGES

const MongoClient = require('mongodb').MongoClient;
const cors = require('cors')();


// Use connect method to connect to the Server
function writeOne(req, res){
    const uri = process.env.MONGO_URI;
    const dbName = 'amazon';
    const client = new MongoClient(uri, { useUnifiedTopology: true });
// Set constant that holds database name

    client.connect(function(err) {
    
    // Set a pointer to the database that we named above
        const db = client.db(dbName);
       // Call the helper function that will insert a single document to the database
        insertDocument(db, req.query.userID, req.query.ISBN, req.query.bookTitle, req.query.price, function(x){
            res.status(200).send(x);
            client.close();
            });
        });
    
}
// END OF PRIMARY APPLICATION LOGIC

exports.writeOne = (req, res) => {
  cors(req, res, () => {
    writeOne(req, res);
  });
}


// HELPER FUNCTIONS

const insertDocument = function(db, userID, ISBN, bookTitle, price, callback) {
  // Set constant that holds the documents collection
   const collection = db.collection('cart');

  // Insert a document

  collection.insertOne({"userID": userID, "ISBN": ISBN, "bookTitle": bookTitle, "price": price}, function(error, result){
    if(error) throw error;
    callback(result);
  });
};

